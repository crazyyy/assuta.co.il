<?php
$SES = array (
  '3940333baa496dbf2c75c6fd302cbc6a' => 
  array (
    'cfg' => 
    array (
      'charsets' => 'cp1251 utf8 latin1',
      'lang' => 'uk',
      'time_web' => '600',
      'time_cron' => '600',
      'backup_path' => 'backup/',
      'backup_url' => 'backup/',
      'only_create' => 'MRG_MyISAM MERGE HEAP MEMORY',
      'globstat' => 0,
      'my_host' => 'localhost',
      'my_port' => 3306,
      'my_user' => 'DBUSER',
      'my_pass' => 'DBPASS',
      'my_comp' => 0,
      'my_db' => '',
      'auth' => 'mysql cfg',
      'user' => '',
      'pass' => '',
      'confirm' => '30',
      'exitURL' => './',
      'outfile_path' => 'backup/',
      'outfile_size' => '64',
    ),
    'time' => 1444749535,
    'lng' => 'uk',
  ),
);
?>